var express = require("express"); // used to create handle routing and process requests from the client
var app = express(); // setting the app to use express 
var mysql = require('mysql'); // Call the sql to action as per teacher lesson

// note: if not installed please install it with cmd: npm install express --save 

//setting views
app.set("view engine", "ejs");
// setting the file system and parser
var fs = require('fs'); 
var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({extended:true}));

var solutions = require("./model/solutions.json"); 
var products = require("./model/product.json");
var contact = require("./model/contact.json"); 
var others = require("./model/others.json");


// Call the access to the views, images and scripts folder and allow content to be rendered
app.use(express.static("views"));
app.use(express.static("script"));
app.use(express.static("images"));

// create connectivity to sql database with my gearhost account, plus log to console for db connection
const db = mysql.createConnection ({
    host: 'den1.mysql3.gear.host',
    user: 'webapppro',
    password: 'Webapppro74!',
    database: 'webapppro'
});

db.connect((err) => {
    if(err){
    console.log("Connection to db failed");
    }
    else {
        console.log("Connection to db established");
    }
 });

// when clicking on Home, below is the route to index.ejs
app.get('/', function(req, res){ 
    res.render("index");
    console.log("working properly @ homepage now");
});

//I want to see if thables are in the db actually, so i print some logs if there are 
var sql = "show tables";
db.query(sql, function (err, result) {
    if (err) throw err;
    else {
    console.log(result);
    }
});

//Creating a new class for data source to be used for data manipulation in sql
let data_source = class dataDB{
  constructor(pid, nname, pprice) {
    this.pid = pid;
    this.name = nname;
    this.price = pprice;
  }
};
console.log(data_source.name + " class successfully created!");

/*
// Create a product table named "bac2"
app.get('/createtable', function(req, res){
  var sql = "CREATE TABLE bac2 (name VARCHAR(255), brand VARCHAR(255), id VARCHAR(255))";
  db.query(sql, function (err, result) {
    if (err) throw err;
    console.log("Table created");
  });
});

//following lines: "try" is code from another person as example of what can be done with node.js as far as data interpolation
try {
    var name = "Andrea";
    var id = "1234";
    var brand = "beer";
    // string interpolation
    db.query(`INSERT INTO bac2 (name, id, brand) VALUES ("${name}", "${id}", "${brand}")`, function (err, result) {
        console.log(result);
    });
    db.query("select * from bac2", function (err, result) {
        console.log(result);
    });
} catch(e){
    console.log(e);
}
*/

app.post('/createsql', function(req, res){
    var { name, id, brand } = req.body; // object destructuring
    let sql = `INSERT INTO bac (name, id, brand) VALUES ("${name}", "${brand}", "${id}" )`;
     let query = db.query(sql, (err,res) => {
        console.log("hello you are under/createsql of app.js code, bacco");
        if(err) throw err;
    });
    res.redirect("/createsql");
});

//running queries to see if there are data in the tables created
db.query('SELECT * FROM bac', (err,rows) => {
  if(err) throw err;
  console.log(rows);
});
db.query('SELECT * FROM bac1', (err,rows) => {
  if(err) throw err;
  console.log(rows);
});

//deleteing records that have no name or name is null
/*
db.query('DELETE FROM bac WHERE name = "undefined"', (err,rows) => {
  if(err) throw err;
  console.log("number deleted " + rows);
});
db.query('DELETE FROM bac WHERE name = ""', (err,rows) => {
  if(err) throw err;
  console.log("number deleted " + rows);
});
db.query('DELETE FROM bac WHERE brand = "undefined"', (err,rows) => {
  if(err) throw err;
  console.log("number deleted " + rows);
});
db.query('DELETE FROM bac WHERE id = "undefined"', (err,rows) => {
  if(err) throw err;
  console.log("number deleted " + rows);
});
db.query('DELETE FROM bac WHERE id = ""', (err,rows) => {
  if(err) throw err;
  console.log("number deleted " + rows);
});
*/

// code to insert a product in the db from form in page and // Route to create a product 
app.get('/createsql', function(req, res) {
    res.render('createsql');
    console.log("under createsql-product page now");
});

//route and query to show product added via sql
app.get('/showallproducts', function(req, res) {
    db.query('SELECT * FROM bac', (err,rows) => {
    if(err) throw err;
    console.log(rows);
    res.render('showallproducts', { rows });
    console.log("under showallproducts product page now");
    });
}); 
//console.log(res);
//res.redirect('/');

//route to delete product added via sql
/*
app.get('/delete_p', function(req, res) {
    var { name, id, brand } = req.body;
    db.query(`DELETE FROM bac WHERE id = "${id}"`, (err,rows) => {
    if(err) throw err;
    console.log(rows);
    res.render('delete_p', { rows });
    console.log("under delete_p product page now");
    });
});


*/

app.post('/delete_p', function(req, res) {
    var { name, id, brand } = req.body;
    db.query('DELETE FROM bac WHERE name = "' + name +'"', (err,rows) => {
    if(err) throw err;
    console.log(rows);
    res.render('createsql');
    console.log("under delete_p product page now");
    });
});

/*global id*/
/*
app.get('/update/:id', function(req,res){
    var { name, id, brand } = req.body;
    function chooseid(bac_3){
        return bac_3.id === (req.body.id)
    }
    var bac_3 = id.filter(chooseid);
     res.render('update', {res:bac_3});
    console.log("under update db product page now"); 
});
*/

/*global bac2*/
//route and query to update product added via sql
app.get('/update/:id', function(req, res) {
    var { name, id, brand } = req.body;
    var {bac2} = req.body;
    res.render('createsql');
//    db.query('UPDATE bac SET name = '+ name +' WHERE name = "' + bac2.name +'"', (err,rows) => {
//    if(err) throw err;
//    console.log(rows);
//    res.render('createsql');
//    console.log("under createsql product page now");
//    });
});


/*
####################################
## route for products ## via json ##
####################################
*/
app.get('/form1', function(req, res) {
    res.render('form1');
    console.log("under form1 for about us");
});
 
// route to get pages
app.get('/contacts', function(req, res){
      res.render("contacts", {contact});
     console.log("bravo bacco, under solutions page now");
});

app.get('/others', function(req, res){
      res.render("others", {others});
     console.log("under others now");
});

app.get('/add', function(req, res){
      res.render("add", {others});
      console.log("under /add page now");
});

function getMax(contacts, key) {
    // reduce function to iterate over an array, run the reduce function for each element and update an cumulative 
    // counter called 'max' and is updated each time the current value is +1 than the previous max value
    // follow the link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/reduce
    var max = contacts.reduce((max, current) => max > current[key] ? max : current[key], 0 );
    console.log(`The max ${key} is ${max}`);
    return max;
}

app.post('/add', function(req,res){
    var maxCid = getMax(contact, "p_id");
    var newId = maxCid + 1; //  variable for id which is 1 larger than the current max
     console.log("New p_id is: " + newId);
     var json = JSON.stringify(contact); //

    // push these two items down to the JSON object, similar to the one in class with teahcer
    var contactsx = {
        name: req.body.name,
        p_id: newId,
     }
     fs.readFile('./model/solutions.json', 'utf8', function readfileCallback(err){
         if(err){
             throw(err);
         } else {
           contact.push(contactsx);  // add the new item [name and id] to the JSON file
           json = JSON.stringify(contact, null, 4); // structure the new data nicely in the JSON file as per teacher code
           fs.writeFile('./model/contact.json', json, 'utf8', err => { //callback handler also needed
               if(err){
                   console.log(err);
                   }
                   else
                   {
                   console.log("bacco: p_id pushed down to json");
               }
           });
         }
     });
     res.redirect('/contacts');
 });

/*
BAC comments: 
1. 'get' operation best practice is to be 'idempotent', meaning it always returns the same result, usually a 'delete' would be done via 
HTTP 'post' operation ... need to remember that
REMINDERS [research over node.js online]:
- data.filter -> run the filter operation for each element in 'data' and return a new array containing only the filtered elements
c=> { return c.p_id != keyToFind } -> Fat Arrow callback function, this  function is called for each element 'c' 
of the 'contact/data' array, return 'true' if the id is not matching the keyToFind. Every 
element 'c' which results in 'true' is added into the array 'remainingContacts' [as per lesson]
- 'remainingContacts' is eventually, the list of contacts which does not include the contact with the ID you wanted to delete
and you can then write this list to the file
- fs.readFile/fs.writeFile need a callback parameter, so I put the log as result
for the delete, I'm deleting from the contacts.json using the 'p_id' value
so it may make more sense to change it to: p_id
*/
app.get('/deletecontact/:p_id', function(req,res){
    
    var json = JSON.stringify(contact);// Get the id to delete from the URL parameter as per class
    var keyToFind = parseInt(req.params.p_id);
    contact = contact.filter(c =>{ return c.p_id !== keyToFind}); // filter 'contact' list and overwrite with the filtered list using p_id as key
    json = JSON.stringify(contact, null, 4) 
    fs.writeFile('./model/contact.json', json, 'utf8', (err) => {
        if (err){
            console.log(err);
        }
    })
    console.log("item is deleted");
    res.redirect('/contacts');
});

// edit item using json  
app.get('/editcontact/:p_id', function(req,res){
    function chooseContact(bac_1){
        return bac_1.p_id === parseInt(req.params.p_id)
    }
    var bac_1 = contact.filter(chooseContact)
     res.render('editcontact', {res:bac_1});
});

// ### post request to edit contact [as per lessons]
app.post('/editcontact/:p_id', function(req,res){
    var json = JSON.stringify(contact);
//reuse some code from class below
    var keyToFind = parseInt(req.params.p_id);  // Find the data to edit
    var data = contact // Declare the json file as a variable called data
    var index = data.map(function(contact){return contact.p_id;}).indexOf(keyToFind) // map out data and find what we need

//adding 2 variables 
    var y = req.body.name; 
    var z = parseInt(req.params.p_id)
    
    contact.splice(index, 1, {
        name: req.body.name,
        Comment: y,
        p_id: z,
        email: req.body.email
     });
    
    json = JSON.stringify(contact, null, 4);
    fs.writeFile("./model/contact.json", json, 'utf8' , (err) =>{
        if(err){
            console.log(err);
        }
    });
    res.redirect("/contacts");
});

// app runnning logs // never write below these lines

app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0", function(){
    
  console.log("app is running on app.js server");
    
    
});