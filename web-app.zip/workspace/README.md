# web-app
webapp for web app development final project
Thats what I wanna do:
[A] create a CRUD app by using SQL [SQL db provided already in app.js via gearhost]: I have successfully created a delete page, I need to
create an update and add page as well.
[B] source data are from a SQL db table that is created on gearhost and json files in the app

I am stuck with some create and delete for json and sql and I am not sure what is wrong in the views and the routes that I have set
